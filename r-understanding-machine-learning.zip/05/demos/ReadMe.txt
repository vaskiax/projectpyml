Demos are available for modules 4, 6, and 7.

The demos for a module builds upon the work performed in the previous modules.  Therefore, to successfully execute the demos for a given module
module you must have successfully executed the demo .R scripts for the previous modules.

Also, the demos are meant to be run within a single R session. If you exit R your session will be dropped and you need to run the
demos again.
